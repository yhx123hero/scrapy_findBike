#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author :cj
# date：2018/8/30
from app import app

app.run(debug=True,host='0.0.0.0',port=5003)