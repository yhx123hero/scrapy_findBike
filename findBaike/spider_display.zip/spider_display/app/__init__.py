#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author :cj
# date：2018/8/30
from flask import Flask

app = Flask(__name__)

from app import views