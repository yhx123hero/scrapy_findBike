#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author :cj
# date：2018/8/30
from app import app
from flask import render_template,request,jsonify
import os
from .txt_deal import txt_deal


dirpath = "./data/txt"


@app.route("/home/")
def home():
    """主页"""
    return render_template("home.html")


@app.route("/home/search_keyword/")
def search():
    """处理查询请求"""
    keyword = request.args.get("keyword","")
    if not keyword:
        return jsonify({"success":False})

    files = os.listdir(dirpath)
    result = []
    for file in files:
        if not os.path.isdir(file):
            if file.find(keyword) != -1:
                result.append(txt_deal(dirpath,file))

    if not result:
        return jsonify({"success":False})

    return jsonify({"success":True,"result":result})
