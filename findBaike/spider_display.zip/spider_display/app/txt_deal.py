#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author :cj
# date：2018/8/30
def txt_deal(dirpath,title):
    """处理文本，返回json数据"""
    result = {"title":title[:-4],"content":"","keyword":"","keyphrase":"","abstract":"","images":[]}
    with open(dirpath + "/" + title,"r",encoding="utf8") as f:
        tmp = ""
        for line in f.readlines():
            if line.startswith("【文章来源"):
                tmp += line
                result["content"] = "content:\n" + tmp
                tmp = ""
                continue
            if line.startswith("keword"):
                result["images"] = tmp[:-1].split("\n")
                tmp = "keyword:\n"
                continue
            if line.startswith("keyphrase"):
                result["keyword"] = tmp
                tmp = "keyphrase:\n"
                continue
            if line.startswith("abstract"):
                result["keyphrase"] = tmp
                tmp = "abstract:\n"
                continue
            tmp += line
        result["abstract"] = tmp

    return result
